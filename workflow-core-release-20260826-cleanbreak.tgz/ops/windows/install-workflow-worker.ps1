param(
    [string]$SourceRoot,
    [Parameter(Mandatory = $true)]
    [string]$JsonlCommand,
    [string]$JsonlArgs = '',
    [string]$InstallRoot = "$env:ProgramData\WorkflowCore",
    [string]$CoreUrl = 'http://127.0.0.1:18710',
    [string]$WorkerId = "windows-$env:COMPUTERNAME",
    [string]$Capabilities = 'workflow-jsonl,windows,powershell',
    [int]$MaxConcurrency = 1,
    [int]$AdminPort = 0,
    [string]$TaskName = 'Workflow Core Worker'
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Security
if ([string]::IsNullOrWhiteSpace($SourceRoot)) {
    $SourceRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
}
$workerToken = [Console]::In.ReadToEnd().Trim()
if ([string]::IsNullOrWhiteSpace($workerToken)) {
    throw 'Worker token is required on standard input. Generate one on Core first:
      POST /api/v1/admin/tokens with role "worker", subject_id = the WorkerId of this machine, and the project_ids it may process.'
}
$runtime = Join-Path $InstallRoot 'runtime'
$secrets = Join-Path $InstallRoot 'secrets'
$startScript = Join-Path $runtime 'ops\windows\start-workflow-worker.ps1'
$node = (Get-Command node.exe -ErrorAction Stop).Source
if ([string]::IsNullOrWhiteSpace($JsonlCommand)) { throw 'JsonlCommand is required' }

New-Item -ItemType Directory -Force -Path $InstallRoot, $runtime, $secrets | Out-Null
& icacls.exe $InstallRoot /inheritance:r /grant:r 'SYSTEM:(OI)(CI)F' 'Administrators:(OI)(CI)F' | Out-Null
if ($LASTEXITCODE -ne 0) { throw "Failed to restrict ACLs on $InstallRoot" }

$plain = [Text.Encoding]::UTF8.GetBytes($workerToken)
try {
    $encrypted = [Security.Cryptography.ProtectedData]::Protect(
        $plain,
        $null,
        [Security.Cryptography.DataProtectionScope]::LocalMachine
    )
    [Convert]::ToBase64String($encrypted) | Set-Content -NoNewline -Encoding Ascii (Join-Path $secrets 'worker-token.dpapi')
} finally {
    [Array]::Clear($plain, 0, $plain.Length)
    $workerToken = $null
}

$args = ($JsonlArgs -split '\|' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
$capabilities = ($Capabilities -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
$settings = @{
    coreUrl = $CoreUrl
    workerId = $WorkerId
    capabilities = $capabilities
    maxConcurrency = $MaxConcurrency
    jsonlCommand = $JsonlCommand
    jsonlArgs = $args
    adminPort = $AdminPort
    version = '0.2.0'
}
$settings | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 (Join-Path $secrets 'worker-settings.json')
if ($LASTEXITCODE -ne 0) { throw 'Failed to write worker settings' }

robocopy $SourceRoot $runtime /MIR /XD node_modules .git /XF '*.log' | Out-Null
if ($LASTEXITCODE -ge 8) { throw "Runtime copy failed with robocopy exit code $LASTEXITCODE" }

& npm.cmd ci --prefix $runtime --registry=https://registry.npmjs.org/ --fetch-retries=1 --fetch-timeout=60000 --no-audit --no-fund --omit=dev
if ($LASTEXITCODE -ne 0) { throw "Workflow runtime dependency install failed" }

$action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File `"$startScript`""
$trigger = New-ScheduledTaskTrigger -AtStartup
$taskSettings = New-ScheduledTaskSettingsSet -RestartCount 12 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew
$principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Settings $taskSettings -Principal $principal -Force | Out-Null
Start-ScheduledTask -TaskName $TaskName

Write-Output "Installed and started $TaskName"
Write-Output "Runtime: $runtime"
Write-Output "State: $(Join-Path $InstallRoot 'state')"
Write-Output "Logs: $(Join-Path $InstallRoot 'logs')"
Write-Output "Core URL: $CoreUrl"
Write-Output "Admin UI: http://127.0.0.1:$AdminPort (port 0 = random; see $(Join-Path $InstallRoot 'state\admin.token'))"
