import { spawn } from 'node:child_process';
import crypto from 'node:crypto';
import { BACKEND_EVENTS } from './contract.js';

const MAX_LINE_BYTES = 1024 * 1024;

function resultError(message, code = 'OMP_RPC_ERROR') {
  const error = new Error(message);
  error.code = code;
  return error;
}

export class OmpRpcBackend {
  constructor({ command = 'omp', args = ['--mode', 'rpc'], cwd = null, env = {}, spawnImpl = spawn, log = () => {}, agentDir = null } = {}) {
    this.command = command; this.args = [...args]; this.cwd = cwd; this.env = { ...env }; this.spawnImpl = spawnImpl; this.log = log; this.agentDir = agentDir; this.sessions = new Map();
  }

  describe() { return { kind: 'omp-rpc', version: '1', capabilities: ['run', 'resume', 'inject', 'cancel', 'interaction'] }; }

  async checkHealth() { return { ok: true, command: this.command }; }

  #key(options) { return options.projectId || options.task?.project_id || options.task?.task_id; }

  #start(key, workspace) {
    const child = this.spawnImpl(this.command, [...this.args], {
      cwd: this.cwd || workspace || process.cwd(),
      env: this.#childEnv(), stdio: ['pipe', 'pipe', 'pipe'],
    });
    const state = { child, buffer: '', pending: new Map(), sessionRef: null, closed: false };
    child.stdout?.setEncoding?.('utf8');
    child.stdout?.on('data', (chunk) => this.#consume(state, String(chunk)));
    child.stderr?.setEncoding?.('utf8');
    child.stderr?.on('data', (chunk) => this.log(`[omp] ${String(chunk).trim()}`));
    const fail = (error) => {
      if (state.closed) return;
      state.closed = true;
      for (const pending of state.pending.values()) pending.reject(error);
      state.pending.clear();
      if (this.sessions.get(key) === state) this.sessions.delete(key);
    };
    child.once?.('error', (error) => fail(error));
    child.once?.('exit', (code, signal) => fail(resultError(`OMP RPC exited (${code ?? signal ?? 'unknown'})`, 'OMP_RPC_EXIT')));
    this.sessions.set(key, state);
    return state;
  }

  #childEnv() {
    const env = { ...process.env, ...this.env };
    for (const key of Object.keys(env)) if (key === 'WFC_WORKER_TOKEN' || key.startsWith('WFC_CORE_')) delete env[key];
    if (this.agentDir) env.OMP_AGENT_DIR = this.agentDir;
    return env;
  }

  #consume(state, chunk) {
    state.buffer += chunk;
    if (Buffer.byteLength(state.buffer, 'utf8') > MAX_LINE_BYTES) { state.child.kill?.('SIGTERM'); return; }
    let index;
    while ((index = state.buffer.indexOf('\n')) >= 0) {
      const line = state.buffer.slice(0, index).trim(); state.buffer = state.buffer.slice(index + 1); if (!line) continue;
      let message; try { message = JSON.parse(line); } catch (error) { this.log(`[omp] invalid JSON-RPC line: ${error.message}`); continue; }
      this.#message(state, message);
    }
  }

  #message(state, message) {
    if (message.id && state.pending.has(String(message.id))) {
      const pending = state.pending.get(String(message.id)); state.pending.delete(String(message.id));
      if (message.error) pending.reject(resultError(message.error.message || 'OMP RPC request failed', message.error.code || 'OMP_RPC_ERROR'));
      else pending.resolve(message.result ?? message);
      return;
    }
    const event = message.event || message.notification || message;
    const pending = [...state.pending.values()].at(-1);
    if (pending && event?.type) pending.emit?.(this.#normalizeEvent(event));
  }

  #normalizeEvent(event) {
    const type = String(event.type || '');
    const map = { 'session.started': 'session_started', 'assistant.delta': 'assistant_delta', 'assistant.message': 'assistant_message', 'tool.started': 'tool_started', 'tool.updated': 'tool_updated', 'tool.finished': 'tool_finished', 'interaction.required': 'interaction_required', 'interaction.resolved': 'interaction_resolved', 'task.completed': 'completed', 'task.failed': 'failed' };
    return { ...event, type: map[type] || (BACKEND_EVENTS.includes(type) ? type : 'progress') };
  }

  #request(state, method, params, hooks = {}) {
    if (!state.child.stdin || state.child.stdin.destroyed) return Promise.reject(resultError('OMP RPC stdin is closed', 'OMP_RPC_CLOSED'));
    const id = crypto.randomUUID();
    return new Promise((resolve, reject) => {
      state.pending.set(id, { resolve, reject, emit: hooks.emit });
      try { state.child.stdin.write(`${JSON.stringify({ jsonrpc: '2.0', id, method, params })}\n`); }
      catch (error) { state.pending.delete(id); reject(error); }
    });
  }

  async run(options) { return this.#execute(options, 'run'); }
  async resume(options) { return this.#execute(options, 'resume'); }

  async #execute(options, method) {
    const key = this.#key(options); const state = this.sessions.get(key) || this.#start(key, options.workspace);
    const request = { task_id: options.task.task_id, session_ref: options.sessionRef, prompt: options.task.brief?.prompt || options.task.brief?.goal || options.task.type, cwd: options.workspace };
    const result = await this.#request(state, method, request, { emit: options.emit });
    const sessionRef = result?.session_ref || result?.sessionRef || options.sessionRef || null;
    if (sessionRef) { state.sessionRef = sessionRef; options.setSessionRef?.(sessionRef); }
    return { kind: result?.kind || 'done', sessionRef, result: result?.result ?? result ?? {} };
  }

  inject({ task, projectId, sessionRef, content }) { const state = this.sessions.get(projectId || task.project_id || task.task_id); if (!state) return false; return this.#request(state, 'inject', { task_id: task.task_id, session_ref: sessionRef, content }).then(() => true).catch(() => false); }
  cancel({ task, projectId, sessionRef }) { const state = this.sessions.get(projectId || task.project_id || task.task_id); if (!state) return false; return this.#request(state, 'cancel', { task_id: task.task_id, session_ref: sessionRef }).then(() => true).catch(() => false); }
  resolveInteraction({ task, projectId, sessionRef, response }) { const state = this.sessions.get(projectId || task.project_id || task.task_id); if (!state) return false; return this.#request(state, 'interaction_response', { task_id: task.task_id, session_ref: sessionRef, response }).then(() => true).catch(() => false); }
  async dispose() { for (const state of this.sessions.values()) state.child.kill?.('SIGTERM'); this.sessions.clear(); }
}
