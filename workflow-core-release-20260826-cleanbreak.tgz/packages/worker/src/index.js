// index.js - generic Workflow Worker daemon.
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';
import { CoreConnection } from './core-client.js';
import { RunStore } from './run-store.js';
import { ConfigStore } from './config-store.js';
import { ProjectRegistry } from './project-registry.js';
import { BackendRegistry } from './backend-registry.js';
import { EnvironmentStore } from './environment-store.js';
import { ProcessSupervisor } from './process-supervisor.js';
import { InteractionBridge } from './interaction-bridge.js';
import { TaskRunner } from './runner.js';
import { JsonlCliAdapter } from './adapters/jsonl.js';
import { CredentialStore } from './credential-store.js';
import { LocalAdminServer } from './local-admin-server.js';

export function loadWorkerConfig(env = process.env) {  if (!env.WFC_CORE_URL) throw new Error('WFC_CORE_URL is required');
  if (!env.WFC_WORKER_TOKEN) throw new Error('WFC_WORKER_TOKEN is required (process environment only)');
  return {
    coreUrl: env.WFC_CORE_URL, token: env.WFC_WORKER_TOKEN,
    workerId: env.WFC_WORKER_ID || `worker-${os.hostname()}`,
    capabilities: (env.WFC_WORKER_CAPABILITIES || 'workflow-jsonl').split(',').map((x) => x.trim()).filter(Boolean),
    projects: [], backends: [], maxConcurrency: Number.isInteger(Number(env.WFC_WORKER_MAX_CONCURRENCY)) && Number(env.WFC_WORKER_MAX_CONCURRENCY) > 0 ? Number(env.WFC_WORKER_MAX_CONCURRENCY) : 2,
    stateDir: env.WFC_WORKER_STATE_DIR || path.join(os.homedir(), '.workflow-worker'), version: '0.2.0',
    jsonlCommand: env.WFC_JSONL_COMMAND || null,
    jsonlArgs: (env.WFC_JSONL_ARGS || '').split('|').filter(Boolean),
    adminEnabled: env.WFC_ADMIN_ENABLED !== 'false', adminPort: Number(env.WFC_ADMIN_PORT || 0), adminToken: env.WFC_ADMIN_TOKEN || null,
  };
}

// Reconcile local run state at startup. Terminal runs whose stable frame is
// still in the outbox will be replayed after reconnect; runs whose frame was
// already acknowledged are dropped because Core already has the terminal state.
export function recoverPendingRuns({ runStore, log = () => {} } = {}) {
  if (!runStore) throw new TypeError('runStore is required');
  let dropped = 0;
  let kept = 0;
  for (const run of runStore.list()) {
    if (run.phase !== 'completion_pending') continue;
    if (!run.terminalFrameId || !runStore.hasFrame(run.terminalFrameId)) {
      runStore.delete(run.taskId);
      log(`[worker] dropped ${run.taskId}: terminal frame ${run.terminalFrameId ?? '(none)'} not pending`);
      dropped += 1;
      continue;
    }
    kept += 1;
  }
  return { dropped, kept };
}

function jsonlBackend(descriptor, log) {
  return new JsonlCliAdapter({ command: descriptor.command, args: descriptor.args ?? [], log });
}

export async function startWorker(config, { log = () => {}, WebSocketImpl, stateStore = null, backends = null, projects = null } = {}) {
  const runStore = stateStore ?? new RunStore({ dataDir: config.stateDir });
  const { dropped, kept } = recoverPendingRuns({ runStore, log });
  if (dropped || kept) log(`[worker] recovered runs: ${kept} pending, ${dropped} dropped`);
  const configStore = new ConfigStore({ dataDir: config.stateDir });
  let saved = configStore.get();
  if (saved.backends.length === 0 && config.jsonlCommand) {
    configStore.upsertBackend({
      kind: 'workflow-jsonl',
      command: config.jsonlCommand,
      args: config.jsonlArgs,
      enabled: true,
      capabilities: ['run', 'resume', 'inject', 'cancel', 'interaction'],
    });
    saved = configStore.get();
  }
  const projectRegistry = projects ?? (() => {
    const registry = new ProjectRegistry({});
    const entries = saved.projects.length ? saved.projects : config.projects;
    for (const project of entries) {
      try { registry.add(project); } catch (error) {
        log(`[worker] skipping project ${project.projectId}: ${error.message}`);
      }
    }
    return registry;
  })();
  const backendRegistry = backends ?? new BackendRegistry({ log });
  for (const descriptor of saved.backends) {
    if (descriptor.enabled === false || !descriptor.command) continue;
    if (backendRegistry.get(descriptor.kind)) continue;
    backendRegistry.register(descriptor.kind, jsonlBackend(descriptor, log), {
      kind: descriptor.kind,
      capabilities: descriptor.capabilities ?? [],
      version: '1',
    });
  }
  await backendRegistry.startAll({ stateDir: config.stateDir, projectRegistry });
  const environmentStore = new EnvironmentStore({ dataDir: config.stateDir });
  const supervisor = new ProcessSupervisor({ log });
  const core = new CoreConnection({ url: config.coreUrl, token: config.token, workerId: config.workerId, runStore, WebSocketImpl,
    register: { machine: os.hostname(), capabilities: config.capabilities, projects: projectRegistry.list().map((p) => p.projectId), backends: backendRegistry.list(), max_concurrency: config.maxConcurrency, version: config.version }, log });
  const interactions = new InteractionBridge({ core, backendRegistry, log });
  const runner = new TaskRunner({ core, backendRegistry, runStore, projectRegistry, interactionBridge: interactions, log, maxSlots: config.maxConcurrency });
  const credentialStore = new CredentialStore({ dataDir: config.stateDir });
  let draining = false;
  const drain = {
    active: () => draining,
    enter: async () => { draining = true; core.send('status', { state: 'draining' }, { durable: false }); return true; },
    exit: async () => { draining = false; core.send('status', { state: 'running' }, { durable: false }); return true; },
  };
  const admin = new LocalAdminServer({ worker: { core, runner, runStore, projectRegistry, backendRegistry, environmentStore, interactions, configStore, config, drain }, credentialStore, port: config.adminPort, token: config.adminToken });
  if (config.adminEnabled !== false) {
    await admin.start();
    const address = admin.address();
    if (address && Number.isInteger(address.port) && address.port !== (saved.admin?.port ?? config.adminPort)) {
      configStore.setAdmin({ port: address.port });
    }
    if (!config.adminToken && admin.token) {
      const tokenFile = path.join(config.stateDir, 'admin.token');
      fs.writeFileSync(tokenFile, `${admin.token}\n`, { mode: 0o600 });
      log(`[worker] admin token written to ${tokenFile}`);
    }
  }
  core.on('config', (payload) => core.applyConfig(payload));
  core.on('dispatch', (payload) => {
    if (draining) return;
    runner.handleDispatch(payload.task ?? payload, { resumed: payload.resumed === true }).catch((error) => log(`[worker] dispatch failed: ${error.message}`));
  });
  core.on('inject', (payload) => runner.handleInject(payload.task_id, payload.content));
  core.on('cancel', (payload) => runner.handleCancel(payload.task_id));
  core.on('interaction_response', (payload) => runner.handleInteractionResponse(payload));
  core.on('interaction_cancel', (payload) => runner.handleInteractionCancel(payload));
  core.connect();
  let stopped = false;
  return { core, runner, runStore, projectRegistry, backendRegistry, environmentStore, supervisor, credentialStore, configStore, admin, drain, stop: async () => { if (stopped) return; stopped = true; await admin.stop(); core.close(); await runner.detachAll(); await backendRegistry.dispose(); await supervisor.stopAll(); runStore.close(); } };
}

export { CredentialStore } from './credential-store.js';
export { LocalAdminServer } from './local-admin-server.js';

export async function main() { const worker = await startWorker(loadWorkerConfig(), { log: (line) => process.stdout.write(`${line}\n`) }); const stop = () => worker.stop().catch((error) => { console.error(error); process.exitCode = 1; }); process.once('SIGINT', stop); process.once('SIGTERM', stop); }
if (process.argv[1]?.endsWith('index.js')) main().catch((error) => { console.error(`[worker] startup failed: ${error.message}`); process.exit(1); });
