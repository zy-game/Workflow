// local-admin-server.js - loopback-only management API and UI for the Worker.
// Binds strictly to 127.0.0.1; mutations require the session token plus CSRF.
// Credential endpoints never return secret values; project/backend mutations
// are persisted through ConfigStore, never sent to Core.
import http from 'node:http';
import crypto from 'node:crypto';
import { JsonlCliAdapter } from './adapters/jsonl.js';

const UI = `<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Workflow Worker 管理</title>
<style>
body{font:14px/1.5 system-ui,sans-serif;margin:0;background:#f5f6f8;color:#1c1e21}
header{background:#20232a;color:#fff;padding:10px 16px;display:flex;gap:12px;align-items:center}
header h1{font-size:16px;margin:0;flex:1}
header a{color:#9fc5ff;text-decoration:none;padding:4px 8px;border-radius:4px}
header a.active{background:#37415a}
main{max-width:960px;margin:16px auto;padding:0 12px}
section{background:#fff;border:1px solid #dde1e6;border-radius:6px;margin-bottom:16px;padding:12px 16px}
section h2{font-size:14px;margin:0 0 10px;color:#333}
table{width:100%;border-collapse:collapse;font-size:13px}
th,td{text-align:left;padding:6px 8px;border-bottom:1px solid #eef0f2;vertical-align:top}
th{color:#666;font-weight:600}
code{background:#f0f2f5;padding:1px 4px;border-radius:3px}
button{background:#2f6fed;color:#fff;border:0;border-radius:4px;padding:5px 12px;cursor:pointer}
button.secondary{background:#6b7280}
button.danger{background:#c0392b}
input{box-sizing:border-box;padding:5px 8px;border:1px solid #c9ced4;border-radius:4px;font:inherit}
form{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:10px 0}
form .wide{grid-column:1/-1}
.badge{display:inline-block;padding:1px 8px;border-radius:10px;font-size:12px}
.badge.ok{background:#d3f0d8;color:#1d7a33}.badge.bad{background:#fbd9d5;color:#a12d20}
.empty{color:#8a9098;padding:6px 0}
.error{color:#c0392b}
.row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
</style>
<header><h1>Workflow Worker</h1><nav>
<a href="#overview">总览</a><a href="#projects">项目</a><a href="#backends">Backends</a>
<a href="#environments">环境</a><a href="#credentials">凭据</a><a href="#runs">运行</a><a href="#interactions">交互</a>
</nav></header>
<main id="app"></main>
<script>
const sections = ['overview','projects','backends','environments','credentials','runs','interactions'];
const state = { token: localStorage.getItem('wfcAdminToken') || '', section: location.hash.slice(1) || 'overview' };
function auth() { return { authorization: 'Bearer ' + state.token, 'x-csrf-token': state.token, 'content-type': 'application/json' }; }
async function api(pathname, options = {}) {
  const response = await fetch(pathname, { ...options, headers: { ...auth(), ...(options.headers || {}) } });
  if (response.status === 401) throw new Error('未授权：请粘贴管理员 token 后重试');
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || ('HTTP ' + response.status));
  return body;
}
function esc(value) { return String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c])); }
function badge(ok, text) { return '<span class="badge ' + (ok ? 'ok' : 'bad') + '">' + esc(text) + '</span>'; }
function table(headers, rows) {
  if (!rows.length) return '<div class="empty">暂无数据</div>';
  return '<table><tr>' + headers.map((h) => '<th>' + esc(h) + '</th>').join('') + '</tr>' +
    rows.map((row) => '<tr>' + row.map((cell) => '<td>' + cell + '</td>').join('') + '</tr>').join('') + '</table>';
}
function render(html) { $('app').innerHTML = html; }
const $ = (id) => document.getElementById(id);
async function load() {
  const hash = location.hash.slice(1);
  if (sections.includes(hash)) state.section = hash;
  if (!state.token) { render('<section><h2>管理员 token</h2><form><input class="wide" id="tokenInput" placeholder="启动日志中的 admin token 或 stateDir/admin.token"><button id="saveToken">保存</button></form></section>'); return; }
  try {
    if (state.section === 'overview') return renderOverview();
    if (state.section === 'projects') return renderProjects();
    if (state.section === 'backends') return renderBackends();
    if (state.section === 'environments') return renderEnvironments();
    if (state.section === 'credentials') return renderCredentials();
    if (state.section === 'runs') return renderRuns();
    if (state.section === 'interactions') return renderInteractions();
  } catch (error) { render('<section><h2>错误</h2><div class="error">' + esc(error.message) + '</div></section>'); }
}
async function renderOverview() {
  const [status, config, backends] = await Promise.all([api('/api/status'), api('/api/config'), api('/api/backends')]);
  const rows = [['Worker ID', esc(status.workerId)], ['版本', esc(status.version)],
    ['Core 连接', status.connected ? badge(true, '已连接') : badge(false, '未连接')],
    ['状态', status.draining ? badge(false, 'draining') : badge(true, 'running')],
    ['配置 revision', esc(config.revision)], ['已注册项目', esc(config.projects)], ['Backends', esc(backends.backends.length)]];
  render('<section><h2>总览</h2>' + table(['项目', '值'], rows) +
    '<div class="row" style="margin-top:10px"><button id="btnDrain">进入 drain</button><button id="btnResume" class="secondary">恢复接收</button>' +
    '<button id="btnLogout" class="danger" style="margin-left:auto">清除 token</button></div></section>');
  $('btnDrain').onclick = async () => { await api('/api/drain', { method: 'POST', body: JSON.stringify({ active: true }) }); load(); };
  $('btnResume').onclick = async () => { await api('/api/drain', { method: 'POST', body: JSON.stringify({ active: false }) }); load(); };
  $('btnLogout').onclick = () => { localStorage.removeItem('wfcAdminToken'); state.token = ''; load(); };
}
async function renderProjects() {
  const projects = await api('/api/projects');
  const rows = projects.map((p) => [esc(p.projectId), esc(p.name), '<code>' + esc(p.root) + '</code>',
    '<button class="danger" data-del-project="' + esc(p.projectId) + '">删除</button>']);
  render('<section><h2>项目</h2>' + table(['ID', '名称', '根目录', ''], rows) +
    '<form><input id="pId" placeholder="projectId" required><input id="pRoot" placeholder="现有目录绝对路径" required>' +
    '<input class="wide" id="pName" placeholder="名称（可选）"><button id="addProject" class="wide">注册项目</button></form></section>');
  $('addProject').onclick = async () => {
    await api('/api/projects', { method: 'POST', body: JSON.stringify({ projectId: $('pId').value, root: $('pRoot').value, name: $('pName').value }) });
    load();
  };
  document.querySelectorAll('[data-del-project]').forEach((button) => { button.onclick = async () => { await api('/api/projects', { method: 'POST', body: JSON.stringify({ delete: true, projectId: button.dataset.delProject }) }); load(); }; });
}
async function renderBackends() {
  const { backends, health } = await api('/api/backends?health=1');
  const healthByKind = Object.fromEntries((health || []).map((h) => [h.kind, h]));
  const rows = backends.map((b) => {
    const h = healthByKind[b.kind];
    return [esc(b.kind), '<code>' + esc(b.command) + '</code>', esc((b.args || []).join(' ')),
      h ? (h.ok ? badge(true, 'ok') : badge(false, h.error || 'down')) : '<span class="empty">未检查</span>',
      b.enabled === false ? badge(false, 'disabled') : badge(true, 'enabled')];
  });
  render('<section><h2>Backends</h2>' + table(['Kind', '命令', '参数', '健康', '启用'], rows) + '</section>');
}
async function renderEnvironments() {
  const environments = await api('/api/environments');
  const rows = environments.map((e) => [esc(e.name),
    Object.entries(e.vars || {}).map(([k, v]) => '<code>' + esc(k) + '=' + esc(v) + '</code>').join('<br>') || '<span class="empty">空</span>',
    '<button class="danger" data-del-env="' + esc(e.name) + '">删除</button>']);
  render('<section><h2>环境</h2>' + table(['名称', '变量', ''], rows) +
    '<form><input id="eName" placeholder="profile 名称" required><input class="wide" id="eVars" placeholder=\'JSON 对象，如 {"PORT":"3000"}；拒绝 TOKEN/SECRET/PASSWORD/KEY 类键\' required>' +
    '<button id="addEnv" class="wide">保存环境</button></form></section>');
  $('addEnv').onclick = async () => {
    let vars;
    try { vars = JSON.parse($('eVars').value); } catch { alert('变量必须是合法 JSON'); return; }
    await api('/api/environments', { method: 'POST', body: JSON.stringify({ name: $('eName').value, vars }) });
    load();
  };
  document.querySelectorAll('[data-del-env]').forEach((button) => { button.onclick = async () => { await api('/api/environments', { method: 'POST', body: JSON.stringify({ delete: true, name: button.dataset.delEnv }) }); load(); }; });
}
async function renderCredentials() {
  const credentials = await api('/api/credentials');
  const rows = credentials.map((c) => [esc(c.id), esc(c.name), esc(c.provider), esc(c.kind), esc(c.reference || '') || '<span class="empty">-</span>',
    '<button class="danger" data-del-cred="' + esc(c.id) + '">删除</button>']);
  render('<section><h2>凭据</h2>' + table(['ID', '名称', 'Provider', '类型', '引用', ''], rows) +
    '<form><input id="cId" placeholder="credential id" required><input id="cName" placeholder="名称">' +
    '<input class="wide" id="cValue" placeholder="机密值（Windows 上 DPAPI 加密后本地存储）">' +
    '<input class="wide" id="cReference" placeholder="或外部引用（非 Windows），如 systemd://cred-name">' +
    '<button id="addCred" class="wide">保存凭据</button></form></section>');
  $('addCred').onclick = async () => {
    const body = { id: $('cId').value, name: $('cName').value };
    if ($('cValue').value) body.value = $('cValue').value;
    if ($('cReference').value) body.reference = $('cReference').value;
    await api('/api/credentials', { method: 'POST', body: JSON.stringify(body) });
    load();
  };
  document.querySelectorAll('[data-del-cred]').forEach((button) => { button.onclick = async () => { await api('/api/credentials', { method: 'POST', body: JSON.stringify({ delete: true, id: button.dataset.delCred }) }); load(); }; });
}
async function renderRuns() {
  const runs = await api('/api/runs');
  const rows = runs.map((r) => [esc(r.taskId), esc(r.phase), esc(r.backendKind), esc(r.sessionRef || '') || '<span class="empty">-</span>',
    esc(r.terminalFrameId || '') || '<span class="empty">-</span>',
    '<button data-cancel-run="' + esc(r.taskId) + '">取消</button>']);
  render('<section><h2>运行</h2>' + table(['任务', '阶段', 'Backend', 'Session', '终态帧', ''], rows) + '</section>');
  document.querySelectorAll('[data-cancel-run]').forEach((button) => { button.onclick = async () => { await api('/api/runs/cancel', { method: 'POST', body: JSON.stringify({ task_id: button.dataset.cancelRun }) }); load(); }; });
}
async function renderInteractions() {
  const interactions = await api('/api/interactions');
  const rows = interactions.map((i) => [esc(i.interaction_id), esc(i.kind), esc(i.status || 'pending'), esc(i.taskId),
    '<button data-cancel-inter="' + esc(i.interaction_id) + '">取消</button>']);
  render('<section><h2>交互</h2>' + table(['交互 ID', '类型', '状态', '任务', ''], rows) + '</section>');
  document.querySelectorAll('[data-cancel-inter]').forEach((button) => { button.onclick = async () => { await api('/api/interactions/cancel', { method: 'POST', body: JSON.stringify({ interaction_id: button.dataset.cancelInter }) }); load(); }; });
}
window.addEventListener('hashchange', load);
document.addEventListener('click', (event) => {
  const save = event.target.closest('#saveToken');
  if (save) { state.token = $('tokenInput').value.trim(); localStorage.setItem('wfcAdminToken', state.token); load(); }
});
setInterval(() => { if (state.token && document.hidden !== true) load(); }, 5000);
load();
</script>`;

function json(res, status, body) {
  const data = JSON.stringify(body);
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'content-length': Buffer.byteLength(data) });
  res.end(data);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
      if (data.length > 1024 * 1024) {
        reject(new Error('request too large'));
        req.destroy();
      }
    });
    req.on('end', () => {
      if (req.destroyed) return;
      try { resolve(data ? JSON.parse(data) : {}); } catch { reject(new Error('invalid JSON')); }
    });
    req.on('error', reject);
  });
}

export class LocalAdminServer {
  constructor({ worker, credentialStore, host = '127.0.0.1', port = 0, token = null, ui = UI } = {}) {
    if (!worker || !credentialStore) throw new TypeError('worker and credentialStore are required');
    if (host !== '127.0.0.1') throw new Error('LocalAdminServer must bind to 127.0.0.1');
    this.worker = worker; this.credentialStore = credentialStore; this.host = host; this.port = port;
    this.token = token || crypto.randomBytes(32).toString('hex'); this.ui = ui; this.server = null;
  }
  originAllowed(req) { const origin = req.headers.origin; return !origin || origin === `http://${this.host}:${this.address()?.port || this.port}`; }
  authenticated(req) { const header = req.headers.authorization || ''; return header === `Bearer ${this.token}` || req.headers['x-session-token'] === this.token; }
  async #handle(req, res) {
    res.setHeader('x-content-type-options', 'nosniff');
    const url = new URL(req.url, `http://${this.host}`); const method = req.method || 'GET';
    if (url.pathname === '/' || url.pathname === '/index.html') { res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }); return res.end(this.ui); }
    if (!this.originAllowed(req) || !this.authenticated(req)) return json(res, 401, { error: 'unauthorized' });
    const mutation = !['GET', 'HEAD', 'OPTIONS'].includes(method);
    if (mutation && req.headers['x-csrf-token'] !== this.token) return json(res, 403, { error: 'csrf_required' });
    if (method === 'OPTIONS') { res.writeHead(204, { 'access-control-allow-origin': url.origin, 'access-control-allow-headers': 'authorization,x-session-token,x-csrf-token,content-type' }); return res.end(); }
    if (!url.pathname.startsWith('/api/')) return json(res, 404, { error: 'not_found' });
    const route = url.pathname.slice(5);
    const worker = this.worker;
    try {
      if (method === 'GET') {
        if (route === 'status') return json(res, 200, { ok: true, workerId: worker.core?.workerId, connected: !!worker.core?.isOpen?.(), draining: !!worker.drain?.active?.(), version: worker.config?.version });
        if (route === 'config') return json(res, 200, { revision: worker.configStore?.get?.().revision ?? worker.config?.config_revision ?? 0, projects: worker.projectRegistry.list().length, backends: worker.backendRegistry.list().length });
        if (route === 'projects') return json(res, 200, worker.projectRegistry.list());
        if (route === 'backends') {
          const list = worker.backendRegistry.list();
          if (url.searchParams.has('health')) return json(res, 200, { backends: list, health: await worker.backendRegistry.health() });
          return json(res, 200, { backends: list });
        }
        if (route === 'environments') return json(res, 200, worker.environmentStore.list());
        if (route === 'runs') return json(res, 200, worker.runStore.list());
        if (route === 'interactions') return json(res, 200, [...(worker.interactions?.pending?.values?.() || [])].map(({ task, interaction, sessionRef }) => ({ taskId: task.task_id, sessionRef, ...interaction })));
        if (route === 'credentials') return json(res, 200, this.credentialStore.list());
      }
      const body = await readBody(req);
      if (route === 'credentials') return json(res, 200, body.delete ? { deleted: this.credentialStore.delete(body.id) } : this.credentialStore.set(body.id, body));
      if (route === 'environments') {
        if (body.delete) return json(res, 200, { deleted: worker.environmentStore.delete(body.name) });
        const vars = body.vars ?? body.value;
        if (!vars || typeof vars !== 'object' || Array.isArray(vars)) throw new TypeError('environment vars are required');
        return json(res, 200, worker.environmentStore.set(body.name, { vars }));
      }
      if (route === 'projects') {
        if (body.delete) {
          worker.configStore?.removeProject(body.projectId);
          return json(res, 200, { deleted: worker.projectRegistry.remove(body.projectId) });
        }
        worker.projectRegistry.add(body);
        worker.configStore?.addProject(body);
        return json(res, 200, worker.projectRegistry.get(body.projectId));
      }
      if (route === 'backends') {
        if (body.delete) {
          worker.configStore?.removeBackend(body.kind);
          return json(res, 200, { deleted: worker.backendRegistry.unregister(body.kind) });
        }
        if (!body.kind || typeof body.command !== 'string' || !body.command) throw new TypeError('backend kind and command are required');
        worker.backendRegistry.register(body.kind, new JsonlCliAdapter({ command: body.command, args: Array.isArray(body.args) ? body.args : [], log: () => {} }), {
          kind: body.kind, capabilities: Array.isArray(body.capabilities) ? body.capabilities : ['run'], version: '1',
        });
        worker.configStore?.upsertBackend({
          kind: body.kind, command: body.command, args: Array.isArray(body.args) ? body.args : [],
          enabled: body.enabled !== false, capabilities: Array.isArray(body.capabilities) ? body.capabilities : ['run'],
        });
        return json(res, 200, worker.backendRegistry.get(body.kind));
      }
      if (route === 'drain') {
        if (!worker.drain) throw new TypeError('drain is not available');
        if (body.active) return json(res, 200, { draining: await worker.drain.enter() });
        return json(res, 200, { draining: await worker.drain.exit() });
      }
      if (route === 'runs/cancel') {
        if (typeof body.task_id !== 'string' || !body.task_id) throw new TypeError('task_id is required');
        return json(res, 200, { cancelled: await worker.runner.handleCancel(body.task_id) });
      }
      if (route === 'interactions/cancel') {
        if (typeof body.interaction_id !== 'string' || !body.interaction_id) throw new TypeError('interaction_id is required');
        const pending = [...(worker.interactions?.pending?.values?.() || [])].find(({ interaction }) => interaction.interaction_id === body.interaction_id);
        if (!pending) throw new TypeError('interaction is not pending locally');
        await worker.runner.handleInteractionCancel({ task_id: pending.task.task_id, interaction_id: body.interaction_id });
        await worker.runner.handleCancel(pending.task.task_id);
        return json(res, 200, { cancelled: true });
      }
      if (route === 'interactions/answer') {
        const { task_id, interaction_id, response } = body;
        if (!task_id || !interaction_id || !response) throw new TypeError('task_id, interaction_id and response are required');
        const ok = await worker.runner.handleInteractionResponse({ task_id, interaction_id, response });
        if (!ok) throw new TypeError('interaction cannot be answered locally');
        return json(res, 200, { answered: true });
      }
      return json(res, 404, { error: 'not_found' });
    } catch (error) { return json(res, 400, { error: error.message }); }
  }
  start() { if (this.server) return Promise.resolve(this); this.server = http.createServer((req, res) => this.#handle(req, res)); return new Promise((resolve, reject) => { this.server.once('error', reject); this.server.listen(this.port, this.host, () => { this.server.removeListener('error', reject); resolve(this); }); }); }
  address() { return this.server?.address(); }
  stop() { return new Promise((resolve) => { if (!this.server) return resolve(); this.server.close(() => { this.server = null; resolve(); }); }); }
}

export { UI as ADMIN_UI };
