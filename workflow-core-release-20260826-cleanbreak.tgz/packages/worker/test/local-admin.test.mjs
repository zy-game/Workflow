import test from 'node:test';
import assert from 'node:assert/strict';
import os from 'node:os';
import fs from 'node:fs';
import path from 'node:path';
import { ConfigStore } from '../src/config-store.js';
import { CredentialStore } from '../src/credential-store.js';
import { EnvironmentStore } from '../src/environment-store.js';
import { LocalAdminServer } from '../src/local-admin-server.js';

const stubProvider = {
  name: 'stub',
  protect: async (plain) => `enc:${plain}`,
  unprotect: async (encrypted) => encrypted.slice(4),
};

function tempDir(prefix) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), prefix));
  return dir;
}

test('credential store persists protected secrets and never exposes values', async () => {
  const dir = tempDir('worker-cred-');
  const store = new CredentialStore({ dataDir: dir, provider: stubProvider });
  await store.set('x', { provider: 'stub', value: 'secret', metadata: { account: 'a' } });
  assert.equal(store.list()[0].provider, 'stub');
  assert.equal(store.list()[0].value, undefined);
  const entry = await store.get('x');
  assert.equal(entry.value, 'secret');
  const raw = JSON.parse(fs.readFileSync(path.join(dir, 'credentials.json'), 'utf8'));
  assert.equal(raw.x.secret, 'enc:secret');
  assert.equal(raw.x.value, undefined);
  assert.equal(await store.delete('x'), true);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('credential store supports external references without a local value', async () => {
  const dir = tempDir('worker-cred-ref-');
  const store = new CredentialStore({ dataDir: dir, provider: stubProvider });
  await store.set('r', { name: 'remote', reference: 'systemd://db-password' });
  const entry = await store.get('r');
  assert.equal(entry.kind, 'reference');
  assert.equal(entry.reference, 'systemd://db-password');
  assert.equal(entry.value, undefined);
  const raw = JSON.parse(fs.readFileSync(path.join(dir, 'credentials.json'), 'utf8'));
  assert.equal(raw.r.secret, undefined);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('environment store rejects secret-like keys and non-string values', () => {
  const dir = tempDir('worker-env-');
  const store = new EnvironmentStore({ dataDir: dir });
  assert.throws(() => store.set('bad', { vars: { API_TOKEN: 'x' } }), /not allowed/);
  assert.throws(() => store.set('bad', { vars: { DB_PASSWORD: 'x' } }), /not allowed/);
  assert.throws(() => store.set('bad', { vars: { ACCESS_KEY_ID: 'x' } }), /not allowed/);
  assert.throws(() => store.set('bad', { vars: { WFC_CORE_URL: 'x' } }), /not allowed/);
  assert.throws(() => store.set('bad', { vars: { PORT: 3000 } }), /must be a string/);
  store.set('good', { vars: { PORT: '3000', DATABASE_URL: 'postgres://local/db' } });
  assert.equal(store.get('good').vars.PORT, '3000');
  assert.equal(store.get('good').vars.DATABASE_URL, 'postgres://local/db');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('config store bumps revisions and persists projects and backends', () => {
  const dir = tempDir('worker-config-');
  const store = new ConfigStore({ dataDir: dir });
  const root = fs.mkdtempSync(path.join(dir, 'root-'));
  assert.equal(store.get().revision, 0);
  store.addProject({ projectId: 'p1', root });
  store.upsertBackend({ kind: 'workflow-jsonl', command: 'bridge', args: ['--x'], capabilities: ['run'] });
  assert.equal(store.get().revision, 2);
  const reopened = new ConfigStore({ dataDir: dir });
  assert.equal(reopened.get().revision, 2);
  assert.equal(reopened.get().projects[0].projectId, 'p1');
  assert.equal(reopened.get().backends[0].command, 'bridge');
  assert.throws(() => store.addProject({ projectId: 'p1', root }), /already exists/);
  assert.equal(store.removeProject('p1'), true);
  assert.equal(store.removeBackend('workflow-jsonl'), true);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('admin server enforces loopback token and csrf', async () => {
  const dir = tempDir('worker-admin-');
  const credentialStore = new CredentialStore({ dataDir: dir, provider: stubProvider });
  const worker = {
    core: { workerId: 'w', isOpen: () => true },
    config: { version: '0.2.0' },
    projectRegistry: { list: () => [], get: () => null, add: () => ({}), remove: () => true },
    backendRegistry: { list: () => [], get: () => null, register: () => ({}), unregister: () => true, health: async () => [] },
    environmentStore: { list: () => [], set: () => ({}), delete: () => true },
    runStore: { list: () => [] },
    interactions: { pending: new Map() },
    configStore: { get: () => ({ revision: 0 }), addProject: () => 1, removeProject: () => true, upsertBackend: () => 1, removeBackend: () => true },
    drain: { active: () => false, enter: async () => true, exit: async () => true },
    runner: { handleCancel: async () => true, handleInteractionCancel: async () => true, handleInteractionResponse: async () => true },
  };
  const server = await new LocalAdminServer({ worker, credentialStore, token: 't' }).start();
  const port = server.address().port;
  let response = await fetch(`http://127.0.0.1:${port}/api/status`);
  assert.equal(response.status, 401);
  response = await fetch(`http://127.0.0.1:${port}/api/status`, { headers: { authorization: 'Bearer t' } });
  assert.equal(response.status, 200);
  response = await fetch(`http://127.0.0.1:${port}/api/credentials`, { method: 'POST', headers: { authorization: 'Bearer t', 'content-type': 'application/json' }, body: JSON.stringify({ id: 'x', value: 's' }) });
  assert.equal(response.status, 403);
  response = await fetch(`http://127.0.0.1:${port}/api/drain`, { method: 'POST', headers: { authorization: 'Bearer t', 'x-csrf-token': 't', 'content-type': 'application/json' }, body: JSON.stringify({ active: true }) });
  assert.equal(response.status, 200);
  assert.equal((await response.json()).draining, true);
  response = await fetch(`http://127.0.0.1:${port}/api/backends?health=1`, { headers: { authorization: 'Bearer t' } });
  assert.equal(response.status, 200);
  response = await fetch(`http://127.0.0.1:${port}/api/projects`, { method: 'POST', headers: { authorization: 'Bearer t', 'x-csrf-token': 't', 'content-type': 'application/json' }, body: JSON.stringify({ projectId: 'p', root: process.cwd(), name: 'demo' }) });
  assert.equal(response.status, 200);
  await server.stop();
  fs.rmSync(dir, { recursive: true, force: true });
});
