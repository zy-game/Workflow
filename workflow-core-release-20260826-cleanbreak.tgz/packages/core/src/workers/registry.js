// registry.js - worker registration and liveness over core.db.
// Heartbeats refresh last_seen; dispatch always reads the current record.
export const WORKER_OFFLINE_MS = 60 * 1000;

const WORKER_STATES = new Set(['running', 'draining', 'offline']);

function normalizeProjects(projects) {
  if (!Array.isArray(projects)) throw new TypeError('projects must be an array');
  return [...new Set(projects.map((project) => {
    if (typeof project === 'string') return project;
    if (project && typeof project.project_id === 'string') return project.project_id;
    throw new TypeError('project entries must have a project_id');
  }).filter(Boolean))];
}

function normalizeBackends(backends) {
  if (!Array.isArray(backends)) throw new TypeError('backends must be an array');
  const seen = new Set();
  return backends.map((backend) => {
    if (!backend || typeof backend !== 'object' || Array.isArray(backend)) {
      throw new TypeError('backend descriptors must be objects');
    }
    const kind = String(backend.kind || '');
    if (!kind) throw new TypeError('backend kind is required');
    if (seen.has(kind)) throw new TypeError(`duplicate backend kind: ${kind}`);
    seen.add(kind);
    if (!Array.isArray(backend.capabilities)) throw new TypeError('backend capabilities must be an array');
    return {
      ...backend,
      kind,
      capabilities: [...new Set(backend.capabilities.map(String).filter(Boolean))],
    };
  });
}

export class WorkersRegistry {
  constructor({ coreDb, db, offlineMs = WORKER_OFFLINE_MS } = {}) {
    this.db = db || coreDb.db;
    this.offlineMs = offlineMs;
  }

  register({
    worker_id, subject_id, machine = null, capabilities = [], selector = {},
    projects = [], backends = [], state = 'running', config_revision = 0,
    max_concurrency = 1, version = null,
  }) {
    if (!worker_id || typeof worker_id !== 'string') throw new TypeError('worker_id is required');
    if (!subject_id || typeof subject_id !== 'string') throw new TypeError('subject_id is required');
    if (!Array.isArray(capabilities)) throw new TypeError('capabilities must be an array');
    if (!WORKER_STATES.has(state)) throw new TypeError(`invalid worker state: ${state}`);
    const concurrency = Number(max_concurrency);
    if (!Number.isInteger(concurrency) || concurrency < 1 || concurrency > 32) {
      throw new TypeError('max_concurrency must be an integer 1-32');
    }
    const revision = Number(config_revision);
    if (!Number.isInteger(revision) || revision < 0) throw new TypeError('config_revision must be a non-negative integer');
    const now = new Date().toISOString();
    this.db.prepare(`
      INSERT INTO workers (
        worker_id, subject_id, machine, capabilities_json, selector_json,
        projects_json, backends_json, state, config_revision,
        max_concurrency, version, last_seen, registered_at, online
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
      ON CONFLICT(worker_id) DO UPDATE SET
        subject_id = excluded.subject_id, machine = excluded.machine,
        capabilities_json = excluded.capabilities_json, selector_json = excluded.selector_json,
        projects_json = excluded.projects_json, backends_json = excluded.backends_json,
        state = excluded.state, config_revision = excluded.config_revision,
        max_concurrency = excluded.max_concurrency, version = excluded.version,
        last_seen = excluded.last_seen, online = 1
    `).run(
      worker_id, subject_id, machine,
      JSON.stringify([...new Set(capabilities.map(String).filter(Boolean))]),
      JSON.stringify(selector ?? {}), JSON.stringify(normalizeProjects(projects)),
      JSON.stringify(normalizeBackends(backends)), state, revision,
      concurrency, version, now, now,
    );
    return this.get(worker_id);
  }

  heartbeat(workerId, { state = null } = {}) {
    if (state !== null && !WORKER_STATES.has(state)) throw new TypeError(`invalid worker state: ${state}`);
    const result = state === null
      ? this.db.prepare('UPDATE workers SET last_seen = ?, online = 1 WHERE worker_id = ?')
        .run(new Date().toISOString(), workerId)
      : this.db.prepare('UPDATE workers SET last_seen = ?, online = 1, state = ? WHERE worker_id = ?')
        .run(new Date().toISOString(), state, workerId);
    return result.changes > 0;
  }

  markDisconnected(workerId) {
    this.db.prepare("UPDATE workers SET online = 0, state = 'offline' WHERE worker_id = ?").run(workerId);
  }

  hasInboundFrame(workerId, frameId) {
    if (!workerId || !frameId) return false;
    return Boolean(this.db.prepare(
      'SELECT 1 AS found FROM worker_inbound_frames WHERE worker_id = ? AND frame_id = ?',
    ).get(workerId, frameId));
  }

  recordInboundFrame(workerId, frameId) {
    if (!workerId || !frameId) return false;
    const result = this.db.prepare(`
      INSERT INTO worker_inbound_frames (worker_id, frame_id, received_at)
      VALUES (?, ?, ?)
      ON CONFLICT(worker_id, frame_id) DO NOTHING
    `).run(workerId, frameId, new Date().toISOString());
    return result.changes > 0;
  }

  get(workerId, now = Date.now()) {
    return this.#rowToWorker(this.db.prepare('SELECT * FROM workers WHERE worker_id = ?').get(workerId), now);
  }

  list({ onlineOnly = false } = {}) {
    const rows = onlineOnly
      ? this.db.prepare('SELECT * FROM workers WHERE online = 1 ORDER BY worker_id').all()
      : this.db.prepare('SELECT * FROM workers ORDER BY worker_id').all();
    const now = Date.now();
    return rows.map((row) => this.#rowToWorker(row, now));
  }

  #rowToWorker(row, now = Date.now()) {
    if (!row) return null;
    const lastSeenMs = Date.parse(row.last_seen);
    return {
      worker_id: row.worker_id,
      subject_id: row.subject_id,
      machine: row.machine,
      capabilities: JSON.parse(row.capabilities_json || '[]'),
      selector: JSON.parse(row.selector_json || '{}'),
      projects: JSON.parse(row.projects_json || '[]'),
      backends: JSON.parse(row.backends_json || '[]'),
      state: row.state || 'running',
      config_revision: Number(row.config_revision || 0),
      max_concurrency: Number(row.max_concurrency),
      version: row.version,
      last_seen: row.last_seen,
      registered_at: row.registered_at,
      connected: Number(row.online) === 1,
      fresh: Number.isFinite(lastSeenMs) && now - lastSeenMs < this.offlineMs,
    };
  }
}
