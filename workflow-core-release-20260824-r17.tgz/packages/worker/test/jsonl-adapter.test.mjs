import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { test } from 'node:test';
import { JsonlCliAdapter } from '../src/adapters/jsonl.js';

function fakeSpawn() {
  const child = new EventEmitter();
  child.stdout = new EventEmitter();
  child.stderr = new EventEmitter();
  child.stdin = {
    destroyed: false,
    write(value) {
      const request = JSON.parse(String(value));
      if (request.type === 'run') {
        child.stdout.emit('data', `${JSON.stringify({ type: 'session', session_ref: 'vendor-session-7' })}\n`);
        child.stdout.emit('data', `${JSON.stringify({ type: 'event', event: { type: 'assistant/message', text: request.prompt } })}\n`);
        child.stdout.emit('data', `${JSON.stringify({ type: 'result', result: { summary: 'ok' } })}\n`);
      }
    },
  };
  child.kill = () => { child.stdin.destroyed = true; };
  return child;
}

test('JSONL adapter keeps one child process per Workflow conversation', async () => {
  const children = [];
  const adapter = new JsonlCliAdapter({ command: 'fake-cli', spawnImpl: (...args) => { const child = fakeSpawn(...args); children.push(child); return child; } });
  const events = [];
  const refs = [];
  const execute = (goal, sessionRef = null) => adapter.execute({
    task: { task_id: `t-${goal}`, type: 'cli.run', brief: { goal } },
    conversationId: 'conv-a', sessionRef, workspace: 'E:/project-a', signal: new AbortController().signal,
    emit: (event) => events.push(event), progress: () => {}, setSessionRef: (ref) => refs.push(ref),
  });
  const first = await execute('first');
  const second = await execute('second', first.sessionRef);
  assert.equal(children.length, 1);
  assert.equal(first.sessionRef, 'vendor-session-7');
  assert.equal(second.sessionRef, 'vendor-session-7');
  assert.deepEqual(refs, ['bridge-conv-a', 'vendor-session-7', 'vendor-session-7', 'vendor-session-7']);
  assert.equal(events.length, 2);
  assert.equal(events[1].text, 'second');
  adapter.close();
});
