import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { test } from 'node:test';
import { CliTaskRunner } from '../src/cli-client.js';

test('CLI runner persists a project conversation across completed tasks', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'wfc-cli-conversation-'));
  const sent = [];
  const seen = [];
  const core = { send(type, payload) { sent.push({ type, payload }); return true; } };
  const adapter = {
    async execute({ conversationId, sessionRef, setSessionRef }) {
      seen.push({ conversationId, sessionRef });
      setSessionRef(sessionRef || 'vendor-session-1');
      return { kind: 'done', sessionRef: sessionRef || 'vendor-session-1', result: { ok: true } };
    },
  };
  const task = (id, goal) => ({
    task_id: id, claim_token: `claim-${id}`, project_id: 'project-a', conversation_id: 'conv-project-a',
    brief: { goal }, status: 'dispatched', workspace: 'E:/project-a',
  });
  try {
    const runner = new CliTaskRunner({ core, adapter, stateDir: dir });
    await runner.dispatch(task('t-1', 'first'));
    await runner.dispatch(task('t-2', 'follow-up'));
    assert.deepEqual(seen, [
      { conversationId: 'conv-project-a', sessionRef: null },
      { conversationId: 'conv-project-a', sessionRef: 'vendor-session-1' },
    ]);
    const persisted = JSON.parse(fs.readFileSync(path.join(dir, 'sessions.json'), 'utf8'));
    assert.equal(persisted.conversations['conv-project-a'], 'vendor-session-1');
    assert.equal(sent.filter((entry) => entry.type === 'task_done').length, 2);

    const resumed = new CliTaskRunner({ core, adapter, stateDir: dir });
    await resumed.dispatch(task('t-3', 'after restart'));
    assert.equal(seen.at(-1).sessionRef, 'vendor-session-1');
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
