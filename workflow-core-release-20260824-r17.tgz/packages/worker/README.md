# Workflow CLI adapters

The Workflow client owns the WebSocket connection and task lease. A vendor adapter owns the local CLI process. The adapter receives a stable `conversationId` and the vendor's `sessionRef`, so a completed task can be followed by another turn in the same project conversation.

## Adapter contract

```js
const adapter = {
  async execute({ task, conversationId, sessionRef, workspace, signal, emit, progress, setSessionRef }) {
    // Start or resume the vendor session, then stream normalized events.
    setSessionRef('vendor-session-id');
    emit({ type: 'assistant/message', text: '...' });
    progress('running', 50);
    return { kind: 'done', sessionRef: 'vendor-session-id', result: { summary: 'done' } };
  },
  inject({ task, conversationId, sessionRef, content }) {
    // Send content to the existing vendor session.
    return true;
  },
  cancel({ task, conversationId, sessionRef }) {
    // Stop the current vendor turn, while keeping the conversation resumable.
    return true;
  },
};
```

`sessionRef` is vendor-specific. `conversationId` is assigned by Workflow and must not be replaced with a new ID for follow-up tasks.

## JSONL bridge

`src/adapters/jsonl.js` provides a generic process adapter. It starts one child process per conversation and sends JSON lines:

```json
{"type":"run","task_id":"t-1","conversation_id":"conv-1","session_ref":"bridge-conv-1","workspace":"/work/app","prompt":"fix the failing test","task":{}}
{"type":"inject","task_id":"t-1","conversation_id":"conv-1","session_ref":"vendor-1","content":"keep the change minimal"}
{"type":"cancel","task_id":"t-1","conversation_id":"conv-1","session_ref":"vendor-1"}
```

The bridge writes JSON lines back:

```json
{"type":"session","session_ref":"vendor-1"}
{"type":"event","event":{"type":"assistant/message","text":"..."}}
{"type":"progress","note":"running","percent":50}
{"type":"result","kind":"done","session_ref":"vendor-1","result":{"summary":"done"}}
```

The bridge is the only vendor-specific code. It can call `codex`, `claude`, `gemini`, or another CLI using that tool's own resume and stream-output options. Do not put vendor credentials in Workflow task payloads or logs.

Example client bootstrap:

```js
import { loadCliClientConfig, startCliClient } from '@workflow-core/worker/cli-client';
import { JsonlCliAdapter } from '@workflow-core/worker/adapters/jsonl';

const config = loadCliClientConfig();
const adapter = new JsonlCliAdapter({ command: process.env.WFC_CLI_BRIDGE });
await startCliClient(config, { adapter });
```

The repository includes a reference Codex bridge at `examples/codex-bridge.mjs`:

```powershell
$env:WFC_CLI_BRIDGE = 'C:\path\to\node.exe'
# The bridge command must include the script path in the adapter args, for example:
$adapter = new JsonlCliAdapter({
  command: 'node',
  args: ['C:\path\to\workflow-core\packages\worker\examples\codex-bridge.mjs'],
})
```

It uses `codex exec --json` for the first turn and `codex exec resume <session-id> --json` for later turns. The same bridge shape can be implemented for Claude Code or Gemini CLI with their respective resume and structured-output options.

Required client environment:

```text
WFC_CORE_URL=https://139.155.78.241:8710
WFC_CLIENT_TOKEN=<client-token>
WFC_CLIENT_ID=<stable-machine-client-id>
WFC_CLIENT_KIND=codex|claude|gemini
WFC_PROJECT_IDS=<project-id-1>,<project-id-2>
WFC_CLIENT_STATE_DIR=<persistent-local-state-directory>
WFC_CLI_BRIDGE=<bridge-executable>
```

Keep `WFC_CLIENT_ID` and `WFC_CLIENT_STATE_DIR` stable across restarts. The client token is only for the client process and must not be passed to the vendor CLI.
