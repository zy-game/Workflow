// Persistent project conversations. A client owns the vendor session, while
// Core keeps the stable project-to-conversation identity and latest session ref.
import crypto from 'node:crypto';

function rowFromDb(row) {
  if (!row) return null;
  return {
    conversation_id: row.conversation_id,
    client_id: row.client_id,
    project_id: row.project_id,
    session_ref: row.session_ref,
    workspace: row.workspace,
    last_task_id: row.last_task_id,
    created_at: row.created_at,
    updated_at: row.updated_at,
  };
}

export class CliConversationRegistry {
  constructor({ coreDb, db } = {}) {
    this.db = db || coreDb.db;
  }

  ensure({ clientId, projectId, workspace = null } = {}) {
    if (!clientId || !projectId) throw new TypeError('clientId and projectId are required');
    const existing = this.getForClientProject(clientId, projectId);
    if (existing) {
      if (workspace && existing.workspace !== workspace) this.update(existing.conversation_id, { workspace });
      return this.get(existing.conversation_id);
    }
    const now = new Date().toISOString();
    const conversationId = `conv-${crypto.randomUUID()}`;
    this.db.prepare(`
      INSERT OR IGNORE INTO cli_conversations(
        conversation_id, client_id, project_id, session_ref, workspace, last_task_id, created_at, updated_at
      ) VALUES (?, ?, ?, NULL, ?, NULL, ?, ?)
    `).run(conversationId, clientId, projectId, workspace, now, now);
    return this.getForClientProject(clientId, projectId);
  }

  get(conversationId) {
    return rowFromDb(this.db.prepare('SELECT * FROM cli_conversations WHERE conversation_id = ?').get(conversationId));
  }

  getForClientProject(clientId, projectId) {
    return rowFromDb(this.db.prepare('SELECT * FROM cli_conversations WHERE client_id = ? AND project_id = ?').get(clientId, projectId));
  }

  update(conversationId, { session_ref, workspace, last_task_id } = {}) {
    const current = this.get(conversationId);
    if (!current) return null;
    this.db.prepare(`
      UPDATE cli_conversations SET
        session_ref = COALESCE(?, session_ref), workspace = COALESCE(?, workspace),
        last_task_id = COALESCE(?, last_task_id), updated_at = ?
      WHERE conversation_id = ?
    `).run(session_ref ?? null, workspace ?? null, last_task_id ?? null, new Date().toISOString(), conversationId);
    return this.get(conversationId);
  }

  list({ clientId = null, projectId = null } = {}) {
    const clauses = [];
    const args = [];
    if (clientId) { clauses.push('client_id = ?'); args.push(clientId); }
    if (projectId) { clauses.push('project_id = ?'); args.push(projectId); }
    const where = clauses.length ? ` WHERE ${clauses.join(' AND ')}` : '';
    return this.db.prepare(`SELECT * FROM cli_conversations${where} ORDER BY updated_at DESC`).all(...args).map(rowFromDb);
  }
}
