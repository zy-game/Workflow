// Authenticated WebSocket channel for project-scoped CLI clients. Clients
// own the actual CLI process/session; Core only leases tasks and relays the
// normalized task/event protocol.
import { WebSocketServer } from 'ws';
import { PROTOCOL_VERSION, frame, isClientFrame, parseFrame } from '@workflow-core/shared';
import { actionsAllow } from '../http/server.js';

const HEARTBEAT_INTERVAL_MS = 30_000;
const CLIENT_PATH = '/client';

export function createClientChannel({ authRepository, taskRepository, clientsRegistry, conversationsRegistry = null, approvalsRegistry = null, feishuService = null, log = () => {} } = {}) {
  const wss = new WebSocketServer({ noServer: true });
  const sessions = new Map(); // client_id -> { ws, client, principal }

  function sendToClient(clientId, frameValue) {
    const session = sessions.get(clientId);
    if (!session || session.ws.readyState !== session.ws.OPEN) return false;
    session.ws.send(JSON.stringify(frameValue));
    return true;
  }

  function activeTaskCount(clientId) {
    return taskRepository.activeForWorker(clientId).length;
  }

  function resumeActiveTasks(session) {
    let resumed = 0;
    for (const task of taskRepository.activeForWorker(session.client.client_id)) {
      if (!sendToClient(session.client.client_id, frame('dispatch', { task, resumed: true }))) break;
      resumed += 1;
    }
    return resumed;
  }

  function dispatchToClient(session) {
    const { client } = session;
    let dispatched = 0;
    const busyConversations = new Set(
      taskRepository.activeForWorker(client.client_id)
        .map((task) => task.conversation_id)
        .filter(Boolean),
    );
    while (activeTaskCount(client.client_id) < client.max_concurrency) {
      const candidate = taskRepository.list({ limit: 200 }).find((entry) =>
        entry.status === 'queued'
        && entry.project_id
        && (client.project_ids.includes('*') || client.project_ids.includes(entry.project_id))
        && (!entry.conversation_id || !busyConversations.has(entry.conversation_id))
        && (!entry.conversation_id || !conversationsRegistry || conversationsRegistry.get(entry.conversation_id)?.client_id === client.client_id)
        && (!conversationsRegistry || !conversationsRegistry.getForClientProject(client.client_id, entry.project_id)
          || conversationsRegistry.getForClientProject(client.client_id, entry.project_id)?.conversation_id === entry.conversation_id
          || !entry.conversation_id)
        && (!client.selector || Object.keys(client.selector).every((key) => {
          const value = client.selector[key];
          if (value === null || value === undefined || value === '') return true;
          const workerValue = entry.worker_selector?.[key];
          return Array.isArray(value) ? (Array.isArray(workerValue) && value.some((item) => workerValue.includes(item))) : workerValue === value;
        }))
      );
      const existingConversation = candidate && conversationsRegistry
        ? conversationsRegistry.getForClientProject(client.client_id, candidate.project_id)
        : null;
      const conversation = candidate && conversationsRegistry
        ? (candidate.conversation_id ? conversationsRegistry.get(candidate.conversation_id) : existingConversation)
          || conversationsRegistry.ensure({ clientId: client.client_id, projectId: candidate.project_id, workspace: candidate.workspace || candidate.brief?.workspace || null })
        : null;
      const task = taskRepository.claim({
        worker_id: client.client_id,
        selector: { transport: 'client', ...(client.selector || {}) },
        project_id: candidate?.project_id,
        // An explicitly empty client scope is not a global client. Use a
        // sentinel so it cannot pick up even project-less compatibility work.
        project_ids: client.project_ids.length ? client.project_ids : ['__client_scope_empty__'],
        executor_kind: client.client_kind || 'cli',
        client_id: client.client_id,
        conversation_id: conversation?.conversation_id ?? null,
      });
      if (!task) break;
      if (task.conversation_id) busyConversations.add(task.conversation_id);
      if (!sendToClient(client.client_id, frame('dispatch', { task }))) {
        taskRepository.db.prepare(
          "UPDATE tasks SET status='queued', claim_token=NULL, claim_worker_id=NULL, lease_deadline=NULL, updated_at=? WHERE task_id=?",
        ).run(new Date().toISOString(), task.task_id);
        break;
      }
      dispatched += 1;
    }
    return dispatched;
  }

  function tryDispatch() {
    let total = 0;
    for (const session of sessions.values()) {
      if (session.client) session.client = clientsRegistry.get(session.client.client_id);
      if (!session.client?.fresh) continue;
      total += dispatchToClient(session);
    }
    return total;
  }

  function requireOwnership(session, payload, { requireClaim = true } = {}) {
    if (!session.client) throw new Error('not registered');
    const task = taskRepository.get(payload.task_id);
    if (!task) {
      const error = new Error('task does not exist');
      error.code = 'TASK_NOT_FOUND';
      throw error;
    }
    if (task.claim_worker_id !== session.client.client_id) throw new Error('task not claimed by this client');
    if (requireClaim && !payload.claim_token) throw new Error('claim_token required');
  }

  async function handleMessage(session, { type, payload }) {
    switch (type) {
      case 'register': {
        const selector = { transport: 'client', ...(payload.selector && typeof payload.selector === 'object' ? payload.selector : {}) };
        const requestedProjects = Array.isArray(payload.project_ids) ? payload.project_ids.map(String) : [];
        const scopedProjects = Array.isArray(session.principal.project_ids) && !session.principal.project_ids.includes('*')
          ? requestedProjects.filter((id) => session.principal.project_ids.includes(id))
          : requestedProjects;
        if (Array.isArray(session.principal.project_ids) && !session.principal.project_ids.includes('*') && scopedProjects.length !== requestedProjects.length) {
          throw new Error('client project scope exceeds token scope');
        }
        const client = clientsRegistry.register({
          client_id: String(payload.client_id || ''),
          subject_id: session.principal.subject_id,
          client_kind: String(payload.client_kind || 'cli'),
          machine: payload.machine ?? null,
          version: payload.version ?? null,
          project_ids: scopedProjects,
          capabilities: Array.isArray(payload.capabilities) ? payload.capabilities : [],
          selector,
          workspace_roots: Array.isArray(payload.workspace_roots) ? payload.workspace_roots : [],
          max_concurrency: payload.max_concurrency ?? 1,
          metadata: payload.metadata ?? {},
        });
        session.client = client;
        const previous = sessions.get(client.client_id);
        if (previous && previous.ws !== session.ws) previous.ws.close();
        sessions.set(client.client_id, session);
        session.ws.send(JSON.stringify(frame('config', {
          protocol_version: PROTOCOL_VERSION,
          heartbeat_interval_ms: HEARTBEAT_INTERVAL_MS,
          client,
        })));
        const resumed = resumeActiveTasks(session);
        log(`[client-ws] ${client.client_id} registered (${client.client_kind}, resumed: ${resumed})`);
        tryDispatch();
        break;
      }
      case 'heartbeat':
        if (!session.client || !clientsRegistry.heartbeat(session.client.client_id)) throw new Error('not registered');
        session.client = clientsRegistry.get(session.client.client_id);
        session.ws.send(JSON.stringify(frame('ping', { server_time: new Date().toISOString() })));
        break;
      case 'progress':
        requireOwnership(session, payload);
        return taskRepository.progress(payload.task_id, String(payload.claim_token || ''), {
          note: payload.note ?? null, percent: payload.percent ?? null,
          events: Array.isArray(payload.events) ? payload.events : [],
        });
      case 'session_event':
        requireOwnership(session, payload, { requireClaim: false });
        if (payload.session_ref && conversationsRegistry) {
          const task = taskRepository.get(payload.task_id);
          if (task?.conversation_id) conversationsRegistry.update(task.conversation_id, { session_ref: payload.session_ref, last_task_id: task.task_id, workspace: payload.workspace ?? task.workspace });
        }
        return taskRepository.appendSessionEvent(payload.task_id, {
          ...(payload.event ?? {}),
          ...(payload.session_ref ? { session_ref: payload.session_ref } : {}),
        }, session.client.client_id);
      case 'inject':
        requireOwnership(session, payload, { requireClaim: false });
        return { delivered: true };
      case 'cancel':
        requireOwnership(session, payload, { requireClaim: false });
        return { delivered: true };
      case 'approval_request':
        requireOwnership(session, payload, { requireClaim: false });
        if (feishuService?.handleApprovalRequest) return feishuService.handleApprovalRequest(payload);
        if (approvalsRegistry) {
          const record = approvalsRegistry.create({ taskId: payload.task_id, tool: payload.tool ?? null, risk: payload.risk ?? null, reason: payload.reason ?? null });
          taskRepository.appendSessionEvent(payload.task_id, { kind: 'approval_request', approval_id: record.approval_id, tool: record.tool, risk: record.risk, reason: record.reason }, session.client.client_id);
          return { approval_id: record.approval_id };
        }
        return { approval_id: null };
      case 'task_done': {
        requireOwnership(session, payload);
        const task = taskRepository.done(payload.task_id, String(payload.claim_token || ''), {
          kind: payload.kind ?? 'done', result: payload.result ?? null,
          session_ref: payload.session_ref ?? null, workspace: payload.workspace ?? null,
        });
        if (task.conversation_id && conversationsRegistry) {
          conversationsRegistry.update(task.conversation_id, { session_ref: payload.session_ref ?? task.session_ref, last_task_id: task.task_id, workspace: payload.workspace ?? task.workspace });
        }
        setImmediate(() => tryDispatch());
        return task;
      }
      case 'capabilities_update': {
        if (!session.client) throw new Error('not registered');
        const requestedProjects = Array.isArray(payload.project_ids)
          ? payload.project_ids.map(String) : session.client.project_ids;
        const principalProjects = session.principal.project_ids;
        if (Array.isArray(principalProjects) && !principalProjects.includes('*')
          && requestedProjects.some((id) => !principalProjects.includes(id))) {
          throw new Error('client project scope exceeds token scope');
        }
        const client = clientsRegistry.register({
          ...session.client,
          client_id: session.client.client_id,
          subject_id: session.client.subject_id,
          client_kind: session.client.client_kind,
          capabilities: Array.isArray(payload.capabilities) ? payload.capabilities : session.client.capabilities,
          project_ids: requestedProjects,
          selector: { transport: 'client', ...(payload.selector ?? session.client.selector ?? {}) },
          max_concurrency: payload.max_concurrency ?? session.client.max_concurrency,
        });
        session.client = client;
        tryDispatch();
        return client;
      }
      case 'error':
        log(`[client-ws] ${session.client?.client_id ?? 'unknown'} error: ${payload.error ?? 'unknown'}`);
        return { logged: true };
      default:
        throw new Error(`unhandled frame: ${type}`);
    }
    return null;
  }

  function handleUpgrade(server) {
    server.on('upgrade', (request, socket, head) => {
      let pathname = '/';
      try { pathname = new URL(request.url, 'http://local').pathname; } catch { /* default */ }
      if (pathname !== CLIENT_PATH) return;
      let principal = null;
      try {
        const header = request.headers.authorization;
        const token = typeof header === 'string' && header.startsWith('Bearer ') ? header.slice(7).trim() : '';
        const machine = token ? authRepository.getMachineToken(token) : null;
        if (!machine) throw new Error('invalid token');
        if (!actionsAllow(machine.principal.actions, 'client:register') && !actionsAllow(machine.principal.actions, 'worker:register')) throw new Error('client scope required');
        principal = machine.principal;
      } catch {
        socket.write('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n');
        socket.destroy();
        return;
      }
      wss.handleUpgrade(request, socket, head, (ws) => {
        const session = { ws, principal, client: null };
        ws.on('message', (data) => {
          let parsed;
          try { parsed = parseFrame(JSON.parse(data.toString())); } catch { return; }
          if (!parsed || !isClientFrame(parsed)) {
            ws.send(JSON.stringify(frame('error', { error: 'invalid client frame' })));
            return;
          }
          handleMessage(session, parsed).catch((error) => {
            log(`[client-ws] frame ${parsed.type} failed: ${error.message}`);
            ws.send(JSON.stringify(frame('error', { error: error.message, in_reply_to: parsed.id })));
          });
        });
        ws.on('close', () => {
          if (session.client && sessions.get(session.client.client_id)?.ws === ws) {
            sessions.delete(session.client.client_id);
            clientsRegistry.markDisconnected(session.client.client_id);
            log(`[client-ws] ${session.client.client_id} disconnected`);
          }
        });
        ws.on('error', () => {});
      });
    });
  }

  const pingTimer = setInterval(() => {
    for (const session of sessions.values()) if (session.ws.readyState === session.ws.OPEN) session.ws.ping();
  }, HEARTBEAT_INTERVAL_MS);
  pingTimer.unref();

  return {
    wss,
    handleUpgrade,
    tryDispatch,
    sendToClient,
    connectedCount: () => sessions.size,
    connectedClients: () => [...sessions.keys()],
    stop: () => {
      clearInterval(pingTimer);
      for (const client of wss.clients) client.terminate();
      sessions.clear();
      wss.close();
    },
  };
}
