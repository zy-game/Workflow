// Registry for non-DSH CLI clients. A client advertises the projects and CLI
// capabilities it can execute; dispatch filtering happens before a task lease
// is claimed so a client cannot steal another project's work.
export const CLIENT_OFFLINE_MS = 60 * 1000;

function parseJson(value, fallback) {
  try { return JSON.parse(value || ''); } catch { return fallback; }
}

function fromRow(row, now = Date.now()) {
  if (!row) return null;
  const lastSeenMs = Date.parse(row.last_seen);
  return {
    client_id: row.client_id,
    subject_id: row.subject_id,
    client_kind: row.client_kind,
    machine: row.machine,
    version: row.version,
    project_ids: parseJson(row.project_ids_json, []),
    capabilities: parseJson(row.capabilities_json, []),
    selector: parseJson(row.selector_json, {}),
    workspace_roots: parseJson(row.workspace_roots_json, []),
    max_concurrency: Number(row.max_concurrency),
    last_seen: row.last_seen,
    registered_at: row.registered_at,
    online: Number(row.online) === 1,
    connected: Number(row.online) === 1,
    fresh: Number.isFinite(lastSeenMs) && now - lastSeenMs < CLIENT_OFFLINE_MS,
    metadata: parseJson(row.metadata_json, {}),
  };
}

export class CliClientRegistry {
  constructor({ coreDb, db, offlineMs = CLIENT_OFFLINE_MS } = {}) {
    this.db = db || coreDb.db;
    this.offlineMs = offlineMs;
  }

  register({ client_id, subject_id, client_kind, machine = null, version = null, project_ids = [], capabilities = [], selector = {}, workspace_roots = [], max_concurrency = 1, metadata = {} } = {}) {
    if (!client_id || typeof client_id !== 'string') throw new TypeError('client_id is required');
    if (!subject_id || typeof subject_id !== 'string') throw new TypeError('subject_id is required');
    if (!client_kind || typeof client_kind !== 'string') throw new TypeError('client_kind is required');
    const concurrency = Number(max_concurrency);
    if (!Number.isInteger(concurrency) || concurrency < 1 || concurrency > 32) throw new TypeError('max_concurrency must be an integer 1-32');
    const now = new Date().toISOString();
    this.db.prepare(`
      INSERT INTO cli_clients(
        client_id, subject_id, client_kind, machine, version, project_ids_json,
        capabilities_json, selector_json, workspace_roots_json, max_concurrency,
        last_seen, registered_at, online, metadata_json
      ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,1,?)
      ON CONFLICT(client_id) DO UPDATE SET
        subject_id=excluded.subject_id, client_kind=excluded.client_kind,
        machine=excluded.machine, version=excluded.version, project_ids_json=excluded.project_ids_json,
        capabilities_json=excluded.capabilities_json, selector_json=excluded.selector_json,
        workspace_roots_json=excluded.workspace_roots_json, max_concurrency=excluded.max_concurrency,
        last_seen=excluded.last_seen, online=1, metadata_json=excluded.metadata_json
    `).run(
      client_id, subject_id, client_kind, machine, version,
      JSON.stringify([...new Set(project_ids)]), JSON.stringify([...new Set(capabilities)]),
      JSON.stringify(selector ?? {}), JSON.stringify(workspace_roots ?? []), concurrency,
      now, now, JSON.stringify(metadata ?? {}),
    );
    return this.get(client_id);
  }

  get(clientId) { return fromRow(this.db.prepare('SELECT * FROM cli_clients WHERE client_id = ?').get(clientId)); }

  heartbeat(clientId) {
    return this.db.prepare('UPDATE cli_clients SET last_seen = ?, online = 1 WHERE client_id = ?')
      .run(new Date().toISOString(), clientId).changes > 0;
  }

  markDisconnected(clientId) {
    this.db.prepare('UPDATE cli_clients SET online = 0 WHERE client_id = ?').run(clientId);
  }

  list({ onlineOnly = false, projectId = null } = {}) {
    const rows = onlineOnly
      ? this.db.prepare('SELECT * FROM cli_clients WHERE online = 1 ORDER BY client_id').all()
      : this.db.prepare('SELECT * FROM cli_clients ORDER BY client_id').all();
    return rows.map((row) => fromRow(row)).filter((client) => !projectId || client.project_ids.includes('*') || client.project_ids.includes(projectId));
  }
}
