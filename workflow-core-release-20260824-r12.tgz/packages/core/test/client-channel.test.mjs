import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { after, before, test } from 'node:test';
import WebSocket from 'ws';
import { AuthRepository } from '../src/auth/repository.js';
import { CoreDatabase } from '../src/db/core-db.js';
import { TaskRepository } from '../src/tasks/repository.js';
import { CliClientRegistry } from '../src/clients/registry.js';
import { createClientChannel } from '../src/ws/client-channel.js';
import { createCoreServer } from '../src/http/server.js';

let dir; let auth; let coreDb; let tasks; let clients; let channel; let server; let base; let admin; let clientToken;

async function waitFor(predicate, label, timeoutMs = 3000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) { const value = await predicate(); if (value) return value; await new Promise((resolve) => setTimeout(resolve, 15)); }
  throw new Error(`timeout waiting for ${label}`);
}

async function api(method, pathname, body, token = admin) {
  const response = await fetch(`${base}${pathname}`, { method, headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` }, body: body === undefined ? undefined : JSON.stringify(body) });
  return { status: response.status, body: await response.json() };
}

before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'wfc-client-'));
  auth = new AuthRepository({ dataDir: dir });
  await auth.createAccount({ email: 'owner@example.com', password: 'correct-horse-battery' });
  coreDb = new CoreDatabase({ dataDir: dir }); tasks = new TaskRepository({ coreDb, claimTimeoutMs: 60_000 }); clients = new CliClientRegistry({ coreDb });
  channel = createClientChannel({ authRepository: auth, taskRepository: tasks, clientsRegistry: clients });
  const core = createCoreServer({ authRepository: auth, taskRepository: tasks, clientsRegistry: clients, clientChannel: channel });
  server = await core.listen({ host: '127.0.0.1', port: 0, tls: null }); channel.handleUpgrade(server); base = `http://127.0.0.1:${server.address().port}`;
  const login = await fetch(`${base}/api/v1/auth/client-login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email: 'owner@example.com', password: 'correct-horse-battery' }) }).then((r) => r.json());
  admin = login.access_token;
  clientToken = (await api('POST', '/api/v1/admin/tokens', { subject_id: 'cli-a', role: 'client', project_ids: ['p-a'] })).body.token;
});

after(() => { channel.stop(); server.close(); auth.close(); coreDb.close(); fs.rmSync(dir, { recursive: true, force: true }); });

function connectClient(token = clientToken, registration = {}) {
  const ws = new WebSocket(`${base.replace(/^http/, 'ws')}/client`, { headers: { authorization: `Bearer ${token}` } });
  const frames = []; ws.on('message', (data) => frames.push(JSON.parse(data.toString())));
  return { ws, frames, next: (type) => waitFor(() => frames.find((frame) => frame.type === type), type) };
}

test('project client registers, receives only its project task, and reports session state', async () => {
  const client = connectClient();
  await new Promise((resolve) => client.ws.once('open', resolve));
  client.ws.send(JSON.stringify({ type: 'register', id: 'register-a', payload: { client_id: 'cli-a', client_kind: 'codex', project_ids: ['p-a'], capabilities: ['codex'], max_concurrency: 1 } }));
  const config = await client.next('config'); assert.equal(config.payload.client.client_kind, 'codex');
  const own = await api('POST', '/api/v1/tasks', { type: 'cli.run', project_id: 'p-a', brief: { goal: 'own task', workspace: 'E:/p-a' } });
  const other = await api('POST', '/api/v1/tasks', { type: 'cli.run', project_id: 'p-b', brief: { goal: 'other task' } });
  const dispatch = await client.next('dispatch'); assert.equal(dispatch.payload.task.task_id, own.body.task.task_id); assert.equal(dispatch.payload.task.executor_kind, 'codex');
  assert.equal((await api('GET', `/api/v1/tasks/${other.body.task.task_id}`)).body.task.status, 'queued');
  client.ws.send(JSON.stringify({ type: 'session_event', id: 'event-a', payload: { task_id: own.body.task.task_id, session_ref: 'codex-session-1', event: { type: 'assistant/message', text: 'working' } } }));
  await waitFor(() => tasks.get(own.body.task.task_id).session_ref === 'codex-session-1', 'session ref persisted');
  client.ws.send(JSON.stringify({ type: 'progress', id: 'progress-a', payload: { task_id: own.body.task.task_id, claim_token: dispatch.payload.task.claim_token, note: 'done soon', percent: 50 } }));
  await waitFor(() => tasks.get(own.body.task.task_id).status === 'running', 'progress');
  client.ws.send(JSON.stringify({ type: 'task_done', id: 'done-a', payload: { task_id: own.body.task.task_id, claim_token: dispatch.payload.task.claim_token, result: { session_ref: 'codex-session-1' } } }));
  await waitFor(() => tasks.get(own.body.task.task_id).status === 'done', 'completion');
  client.ws.close();
});
