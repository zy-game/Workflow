// Project-scoped CLI client. The core only leases work; an adapter owns the
// vendor CLI process and keeps its session reference stable across reconnects.
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import WebSocket from 'ws';
import { frame } from '@workflow-core/shared';

export class CliClientConnection {
  constructor({ url, token, registration, log = () => {}, WebSocketImpl = WebSocket }) {
    this.url = url.replace(/\/$/, ''); this.token = token; this.registration = registration;
    this.log = log; this.WebSocketImpl = WebSocketImpl; this.ws = null; this.closed = false;
    this.handlers = new Map(); this.heartbeatMs = 30_000; this.timer = null; this.backoff = 500;
  }
  on(type, handler) { this.handlers.set(type, handler); return this; }
  send(type, payload = {}) {
    if (!this.ws || this.ws.readyState !== this.WebSocketImpl.OPEN) return false;
    this.ws.send(JSON.stringify(frame(type, payload))); return true;
  }
  connect() {
    if (this.closed) return;
    const ws = new this.WebSocketImpl(`${this.url.replace(/^http/, 'ws')}/client`, { headers: { authorization: `Bearer ${this.token}` } });
    this.ws = ws;
    ws.on('open', () => { this.backoff = 500; this.send('register', this.registration); });
    ws.on('message', (data) => { let value; try { value = JSON.parse(data.toString()); } catch { return; }
      if (value.type === 'config') { this.heartbeatMs = value.payload?.heartbeat_interval_ms || this.heartbeatMs; this.#heartbeat(); }
      this.handlers.get(value.type)?.(value.payload ?? {}, value);
    });
    ws.on('close', () => { clearInterval(this.timer); this.timer = null; if (!this.closed) { setTimeout(() => this.connect(), this.backoff).unref?.(); this.backoff = Math.min(30_000, this.backoff * 2); } });
    ws.on('error', () => {});
  }
  #heartbeat() { clearInterval(this.timer); this.timer = setInterval(() => this.send('heartbeat'), this.heartbeatMs); this.timer.unref?.(); }
  close() { this.closed = true; clearInterval(this.timer); this.ws?.terminate?.(); }
}

export class CliTaskRunner {
  constructor({ core, adapter, stateDir = path.join(os.homedir(), '.workflow-cli-client'), workspaceResolver = (task) => task.workspace || task.brief?.workspace || process.cwd(), log = () => {} }) {
    this.core = core; this.adapter = adapter; this.log = log; this.workspaceResolver = workspaceResolver;
    this.stateFile = path.join(stateDir, 'sessions.json'); fs.mkdirSync(stateDir, { recursive: true });
    try { this.sessions = JSON.parse(fs.readFileSync(this.stateFile, 'utf8')); } catch { this.sessions = {}; }
    this.running = new Map();
  }
  #save() { fs.writeFileSync(this.stateFile, JSON.stringify(this.sessions, null, 2)); }
  async dispatch(task, resumed = false) {
    if (this.running.has(task.task_id)) return;
    const prior = this.sessions[task.task_id] || null;
    const workspace = this.workspaceResolver(task);
    const controller = new AbortController();
    this.running.set(task.task_id, { controller, task });
    const setSessionRef = (sessionRef) => { if (sessionRef) { this.sessions[task.task_id] = sessionRef; this.#save(); } };
    const emit = (event) => this.core.send('session_event', { task_id: task.task_id, event, session_ref: this.sessions[task.task_id] || prior });
    const progress = (note, percent, events = []) => this.core.send('progress', { task_id: task.task_id, claim_token: task.claim_token, note, percent, events });
    try {
      progress(resumed ? 'resumed' : 'started', 0);
      const result = await this.adapter.execute({ task, sessionRef: prior, workspace, signal: controller.signal, emit, progress, setSessionRef });
      const sessionRef = result?.sessionRef || prior;
      setSessionRef(sessionRef);
      this.core.send('task_done', { task_id: task.task_id, claim_token: task.claim_token, kind: result?.kind || 'done', session_ref: sessionRef, workspace, result: result?.result ?? result ?? {} });
    } catch (error) {
      if (!controller.signal.aborted) this.core.send('task_done', { task_id: task.task_id, claim_token: task.claim_token, kind: 'failed', result: { error: error.message } });
    } finally { this.running.delete(task.task_id); }
  }
  inject(taskId, content) { const slot = this.running.get(taskId); return slot ? this.adapter.inject?.({ task: slot.task, sessionRef: this.sessions[taskId], content }) : false; }
  cancel(taskId) { const slot = this.running.get(taskId); if (!slot) return false; slot.controller.abort(); this.adapter.cancel?.({ task: slot.task, sessionRef: this.sessions[taskId] }); return true; }
}

export async function startCliClient(config, { adapter, log = () => {} } = {}) {
  if (!adapter || typeof adapter.execute !== 'function') throw new TypeError('a CLI adapter with execute() is required');
  const core = new CliClientConnection({ url: config.coreUrl, token: config.token, registration: {
    client_id: config.clientId, client_kind: config.clientKind, project_ids: config.projectIds,
    capabilities: config.capabilities, workspace_roots: config.workspaceRoots, max_concurrency: config.maxConcurrency,
    machine: os.hostname(), version: config.version,
  }, log });
  const runner = new CliTaskRunner({ core, adapter, stateDir: config.stateDir, log });
  core.on('dispatch', (payload) => runner.dispatch(payload.task ?? payload, payload.resumed === true));
  core.on('inject', (payload) => runner.inject(payload.task_id, payload.content));
  core.on('cancel', (payload) => runner.cancel(payload.task_id));
  core.connect();
  return { core, runner, stop: async () => core.close() };
}

export function loadCliClientConfig(env = process.env) {
  if (!env.WFC_CORE_URL || !env.WFC_CLIENT_TOKEN) throw new Error('WFC_CORE_URL and WFC_CLIENT_TOKEN are required');
  return { coreUrl: env.WFC_CORE_URL, token: env.WFC_CLIENT_TOKEN, clientId: env.WFC_CLIENT_ID || `${os.hostname()}-${env.WFC_CLIENT_KIND || 'cli'}`, clientKind: env.WFC_CLIENT_KIND || 'cli', projectIds: (env.WFC_PROJECT_IDS || '').split(',').map((x) => x.trim()).filter(Boolean), capabilities: (env.WFC_CLIENT_CAPABILITIES || '').split(',').map((x) => x.trim()).filter(Boolean), workspaceRoots: (env.WFC_WORKSPACE_ROOTS || '').split(';').map((x) => x.trim()).filter(Boolean), maxConcurrency: Number(env.WFC_CLIENT_MAX_CONCURRENCY || 1), stateDir: env.WFC_CLIENT_STATE_DIR || path.join(os.homedir(), '.workflow-cli-client'), version: '0.1.0' };
}
